// Task:
// Write a comment block that describes the following code